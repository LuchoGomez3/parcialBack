package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.dto.InvoiceDto;

public interface InvoiceService extends Service<InvoiceDto, Integer>{
}
