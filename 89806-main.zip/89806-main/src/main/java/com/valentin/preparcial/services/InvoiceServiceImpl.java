package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.Invoice;
import com.valentin.preparcial.entities.dto.InvoiceDto;
import com.valentin.preparcial.repositories.InvoiceRepository;
import com.valentin.preparcial.services.mappers.invoice.InvoiceDtoMapper;
import com.valentin.preparcial.services.mappers.invoice.InvoiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class InvoiceServiceImpl implements InvoiceService{
    private final InvoiceRepository invoiceRepository;
    private final InvoiceDtoMapper invoiceDtoMapper;
    private final InvoiceMapper invoiceMapper;

    @Autowired
    public InvoiceServiceImpl(InvoiceRepository invoiceRepository,
                              InvoiceDtoMapper invoiceDtoMapper,
                              InvoiceMapper invoiceMapper) {
        this.invoiceRepository = invoiceRepository;
        this.invoiceDtoMapper = invoiceDtoMapper;
        this.invoiceMapper = invoiceMapper;
    }

    @Override
    public void add(InvoiceDto entity) {
        Invoice invoice = Optional.of(entity).map(invoiceMapper).orElseThrow();
        invoiceRepository.save(invoice);

    }

    @Override
    public InvoiceDto getById(Integer id) {
        Optional<Invoice> optionalInvoice = invoiceRepository.findById(id);
        return  optionalInvoice
                .map(invoiceDtoMapper)
                .orElseThrow();
    }

    @Override
    public List<InvoiceDto> getAll() {
        List<Invoice> invoices = invoiceRepository.findAll();
        return  invoices
                .stream()
                .map(invoiceDtoMapper)
                .toList();
    }

    @Override
    public InvoiceDto delete(Integer id) {
        Optional<Invoice> optionalInvoice = invoiceRepository.findById(id);
        optionalInvoice.ifPresent(invoiceRepository::delete);

        return optionalInvoice
                .map(invoiceDtoMapper)
                .orElseThrow();
    }

    @Override
    public void update(InvoiceDto entity) {
        Optional<Invoice> optionalInvoice = Stream.of(entity).map(invoiceMapper).findFirst();
        optionalInvoice.ifPresent(invoiceRepository::save);
    }
}
