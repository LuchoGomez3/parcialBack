package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.dto.PlaylistTrackDto;
public interface PlaylistTrackService extends Service<PlaylistTrackDto, Integer>{
}
