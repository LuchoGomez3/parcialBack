package com.valentin.preparcial.services.mappers.playlistTrack;

import com.valentin.preparcial.entities.PlaylistTrack;
import com.valentin.preparcial.entities.dto.PlaylistTrackDto;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class PlaylistTrackDtoMapper implements Function<PlaylistTrack, PlaylistTrackDto> {
    @Override
    public PlaylistTrackDto apply(PlaylistTrack playlistTrack) {
        return new PlaylistTrackDto(
                playlistTrack.getPlaylistId(),
                playlistTrack.getTrackId()
        );
    }
}
