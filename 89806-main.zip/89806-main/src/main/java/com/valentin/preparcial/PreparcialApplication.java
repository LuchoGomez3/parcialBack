package com.valentin.preparcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreparcialApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreparcialApplication.class, args);
	}

}
