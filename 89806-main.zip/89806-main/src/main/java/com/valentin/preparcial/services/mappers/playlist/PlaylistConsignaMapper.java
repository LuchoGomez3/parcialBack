package com.valentin.preparcial.services.mappers.playlist;

import com.valentin.preparcial.entities.Playlist;
import com.valentin.preparcial.entities.Track;
import com.valentin.preparcial.entities.dto.PlaylistEnuciado;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class PlaylistConsignaMapper implements Function<Playlist, PlaylistEnuciado> {


    @Override
    public PlaylistEnuciado apply(Playlist playlist) {
        int duracionTotal = playlist.getTracks().stream()
                .mapToInt(Track::getMillisecionds)
                .sum();
        int duracionTotalSegudos = duracionTotal / 1000;

        return new PlaylistEnuciado(
                playlist.getName(),
                duracionTotal,
                playlist.getTracks()
        );
    }
}
