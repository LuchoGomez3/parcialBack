package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.Playlist;
import com.valentin.preparcial.entities.dto.PlaylistDto;
import com.valentin.preparcial.entities.dto.PlaylistEnuciado;

public interface PlaylistService extends Service<PlaylistDto, Integer>{
    void addPlayListConsigna(String nombrePlaylist,
                                         Integer customerId,
                                         Integer genreId,
                                         String composerFilter);
}
