package com.valentin.preparcial.services.mappers.track;

import com.valentin.preparcial.entities.Track;
import com.valentin.preparcial.entities.dto.TrackByCustomerGenre;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class TrackCustomerGenreMapper implements Function<Track, TrackByCustomerGenre> {
    @Override
    public TrackByCustomerGenre apply(Track track) {
        int seconds = track.getMillisecionds() / 1000;
        return new TrackByCustomerGenre(
                track.getTrackId(),
                track.getName(),
                track.getComposer(),
                seconds
        );
    }
}
