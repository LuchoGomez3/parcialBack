package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.dto.CustomerDto;

public interface CustomerService extends Service<CustomerDto, Integer>{
}
