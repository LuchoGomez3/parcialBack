package com.valentin.preparcial.services.mappers.invoiceItem;

import com.valentin.preparcial.entities.InvoiceItem;
import com.valentin.preparcial.entities.dto.InvoiceItemDto;
import com.valentin.preparcial.repositories.InvoiceRepository;
import com.valentin.preparcial.repositories.TrackRepository;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class InvoiceItemMapper implements Function<InvoiceItemDto, InvoiceItem> {
    private final InvoiceRepository invoiceRepository;
    private final TrackRepository trackRepository;

    public InvoiceItemMapper(InvoiceRepository invoiceRepository, TrackRepository trackRepository) {
        this.invoiceRepository = invoiceRepository;
        this.trackRepository = trackRepository;
    }

    @Override
    public InvoiceItem apply(InvoiceItemDto invoiceItemDto) {
        return new InvoiceItem(
                invoiceItemDto.getInvoiceLineId(),
                invoiceRepository.getReferenceById(invoiceItemDto.getInvoiceId()),
                trackRepository.getReferenceById(invoiceItemDto.getTrackId()),
                invoiceItemDto.getUnitPrice(),
                invoiceItemDto.getQuantity()
        );
    }
}
