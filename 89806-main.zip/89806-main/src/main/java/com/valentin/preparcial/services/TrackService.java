package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.dto.TrackByCustomerGenre;
import com.valentin.preparcial.entities.dto.TrackDto;

import java.util.List;

public interface TrackService extends Service<TrackDto, Integer>{
    List<TrackByCustomerGenre> getAllByCustomerGender(Integer customerId, Integer genreId);
}
