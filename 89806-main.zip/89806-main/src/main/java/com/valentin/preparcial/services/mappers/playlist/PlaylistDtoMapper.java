package com.valentin.preparcial.services.mappers.playlist;

import com.valentin.preparcial.entities.Playlist;
import com.valentin.preparcial.entities.dto.PlaylistDto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.function.Function;

@Service
public class PlaylistDtoMapper implements Function<Playlist, PlaylistDto> {
    @Override
    public PlaylistDto apply(Playlist playlist) {
        return new PlaylistDto(
                playlist.getPlaylistId(),
                playlist.getName()
        );
    }
}
