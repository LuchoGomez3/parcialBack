package com.valentin.preparcial.services.mappers.track;

import com.valentin.preparcial.entities.Track;
import com.valentin.preparcial.entities.dto.TrackDto;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class TrackDtoMapper implements Function<Track, TrackDto> {
    @Override
    public TrackDto apply(Track track) {
        return new TrackDto(
                track.getTrackId(),
                track.getName(),
                track.getAlbum().getAlbumId(),
                track.getMediaType().getMediaTypeId(),
                track.getGenre().getGenreId(),
                track.getComposer(),
                track.getMillisecionds(),
                track.getBytes(),
                track.getUnitPrice()
        );
    }
}
