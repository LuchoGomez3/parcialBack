package com.valentin.preparcial.services.mappers.invoiceItem;

import com.valentin.preparcial.entities.InvoiceItem;
import com.valentin.preparcial.entities.dto.InvoiceItemDto;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class InvoiceItemDtoMapper implements Function<InvoiceItem, InvoiceItemDto> {
    @Override
    public InvoiceItemDto apply(InvoiceItem invoiceItem) {
        return new InvoiceItemDto(
                invoiceItem.getInvoiceLineId(),
                invoiceItem.getInvoice().getInvoiceId(),
                invoiceItem.getTrack().getTrackId(),
                invoiceItem.getUnitPrice(),
                invoiceItem.getQuantity()
        );
    }
}
