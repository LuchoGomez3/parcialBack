package com.valentin.preparcial.services.mappers.invoice;

import com.valentin.preparcial.entities.Invoice;
import com.valentin.preparcial.entities.dto.InvoiceDto;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class InvoiceDtoMapper implements Function<Invoice, InvoiceDto> {
    @Override
    public InvoiceDto apply(Invoice invoice) {
        return new InvoiceDto(
                invoice.getInvoiceId(),
                invoice.getCustomer().getCustomerID(),
                invoice.getInvoiceDate(),
                invoice.getBillingAddress(),
                invoice.getBillingCity(),
                invoice.getBillingState(),
                invoice.getBillingCountry(),
                invoice.getBillingPostalCode(),
                invoice.getTotal()
        );
    }
}
