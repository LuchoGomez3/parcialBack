package com.valentin.preparcial.services.mappers.track;

import com.valentin.preparcial.entities.Track;
import com.valentin.preparcial.entities.dto.TrackDto;
import com.valentin.preparcial.repositories.AlbumRepository;
import com.valentin.preparcial.repositories.GenreRepository;
import com.valentin.preparcial.repositories.MediaTypeRepository;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class TrackMapper implements Function<TrackDto, Track> {
    private final AlbumRepository albumRepository;
    private final GenreRepository genreRepository;
    private final MediaTypeRepository mediaTypeRepository;

    public TrackMapper(AlbumRepository albumRepository,
                       GenreRepository genreRepository,
                       MediaTypeRepository mediaTypeRepository) {
        this.albumRepository = albumRepository;
        this.genreRepository = genreRepository;
        this.mediaTypeRepository = mediaTypeRepository;
    }

    @Override
    public Track apply(TrackDto trackDto) {
        return new Track(
                trackDto.getTrackId(),
                trackDto.getName(),
                albumRepository.getReferenceById(trackDto.getAlbumId()),
                mediaTypeRepository.getReferenceById(trackDto.getMediaTypeId()),
                genreRepository.getReferenceById(trackDto.getGenreId()),
                trackDto.getComposer(),
                trackDto.getMilliseconds(),
                trackDto.getBytes(),
                trackDto.getUnitPrice(),
                null,
                null
        );
    }
}
