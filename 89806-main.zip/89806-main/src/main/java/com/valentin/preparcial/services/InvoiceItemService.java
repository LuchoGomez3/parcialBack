package com.valentin.preparcial.services;

import com.valentin.preparcial.entities.InvoiceItem;
import com.valentin.preparcial.entities.dto.InvoiceItemDto;
import com.valentin.preparcial.services.Service;

import java.util.List;

public interface InvoiceItemService extends Service<InvoiceItemDto, Integer> {
    List<InvoiceItem> getByCustomer(Integer customerId);
}
