package com.valentin.preparcial.services.mappers.playlistTrack;

import com.valentin.preparcial.entities.PlaylistTrack;
import com.valentin.preparcial.entities.dto.PlaylistTrackDto;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
public class PlaylistTrackMapper implements Function<PlaylistTrackDto, PlaylistTrack> {
    @Override
    public PlaylistTrack apply(PlaylistTrackDto playlistTrackDto) {
        return new PlaylistTrack(
                playlistTrackDto.getPlaylistId(),
                playlistTrackDto.getTrackId()
        );
    }
}
