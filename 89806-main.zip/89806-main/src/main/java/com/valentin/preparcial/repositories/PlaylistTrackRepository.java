package com.valentin.preparcial.repositories;

import com.valentin.preparcial.entities.PlaylistTrack;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlaylistTrackRepository extends JpaRepository<PlaylistTrack, Integer> {
}
